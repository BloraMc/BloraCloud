import socket
import threading
import json
import base64
from PIL import Image
from io import BytesIO

HOST = "0.0.0.0"
PORT = 25565

# -----------------------------
#  MOTD + DISCONNECT MESSAGE
# -----------------------------
motd_text = (
    "§dTryToChill §bNetwork §d§lASIA §72020 - 2023\n"
    "§bJoin us with §dmc.trytochill.net §b!"
)

disconnect_text = (
    "§dTryToChill §bAsia\n\n"
    "§dTTC AS §bhas ended ...\n"
    "§bJoin us on §dplay.trytochill.net §b!"
)

# -----------------------------
#  LOAD + RESIZE FAVICON (LOCAL)
# -----------------------------
def load_favicon(path):
    img = Image.open(path).convert("RGBA")
    img = img.resize((64, 64), Image.LANCZOS)

    buffer = BytesIO()
    img.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"

favicon = load_favicon("icon.png")


# -----------------------------
#  VARINT HELPERS
# -----------------------------
def read_varint(sock):
    num = 0
    for i in range(5):
        byte = sock.recv(1)
        if not byte:
            return 0
        val = byte[0]
        num |= (val & 0x7F) << (7 * i)
        if not (val & 0x80):
            break
    return num


def write_varint(value):
    out = b""
    while True:
        temp = value & 0x7F
        value >>= 7
        if value != 0:
            temp |= 0x80
        out += bytes([temp])
        if value == 0:
            break
    return out


def send_packet(sock, packet_id, data):
    packet = write_varint(packet_id) + data
    sock.send(write_varint(len(packet)) + packet)


# -----------------------------
#  CLIENT HANDLER
# -----------------------------
def handle_client(conn, addr):
    try:
        read_varint(conn)  # packet length
        packet_id = read_varint(conn)
        if packet_id != 0x00:
            conn.close()
            return

        protocol_version = read_varint(conn)
        host_len = read_varint(conn)
        conn.recv(host_len)
        conn.recv(2)
        next_state = read_varint(conn)

        # STATUS
        if next_state == 1:
            read_varint(conn)

            response = {
                "version": {"name": "TryToChill Asia", "protocol": protocol_version},
                "players": {"max": 2000, "online": 427},
                "description": {"text": motd_text},
                "favicon": favicon
            }

            json_data = json.dumps(response).encode("utf-8")
            send_packet(conn, 0x00, write_varint(len(json_data)) + json_data)

            read_varint(conn)
            payload = conn.recv(8)
            send_packet(conn, 0x01, payload)

        # LOGIN → kick
        elif next_state == 2:
            read_varint(conn)
            name_len = read_varint(conn)
            conn.recv(name_len)

            msg = json.dumps({"text": disconnect_text}).encode("utf-8")
            send_packet(conn, 0x00, write_varint(len(msg)) + msg)

    except:
        pass
    finally:
        conn.close()


# -----------------------------
#  MAIN LOOP
# -----------------------------
def start_server():
    print("Fake MOTD server running on port", PORT)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen()

    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()


if __name__ == "__main__":
    start_server()

